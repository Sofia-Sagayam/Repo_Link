package dt2.bckend.DAO;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import dt2.bckend.model.User;

@Repository
public class UserDao implements UDao {

	@Autowired
	private SessionFactory sessionFactory;

		public User registerUser(User user) {
	        Session session=sessionFactory.openSession();
	        session.save(user);
	        session.flush();
	        session.close();
			System.out.println("success");
	        return user;
		}
		
		public User login(User user) {
			Session session=sessionFactory.openSession();
			//select * from user_batch15 where username=user.getUsername() and password=user.getPassword()
			Query query=session.createQuery("from user_link where username=? and password=?");
			//from user where username='john' and password='123'
			query.setString(0, user.getUsername());
			query.setString(1, user.getPassword());
			User validUser=(User)query.uniqueResult();
			return validUser;
			
		}

		public void updateUser(User user) {
			Session session=sessionFactory.openSession();
			//update user_batch15 set username=?,password=?,email=?,enabled=?,online=? where id=?
			session.update(user);
			session.flush();
			session.close();
		}

}
