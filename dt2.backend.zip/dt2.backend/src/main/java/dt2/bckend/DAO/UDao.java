package dt2.bckend.DAO;

import dt2.bckend.model.User;

public interface UDao {
	User registerUser(User user);
	User login(User user);
	void updateUser(User user);
}
